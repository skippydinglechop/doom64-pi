Doom64EX - PortMaster-style port for Batocera (Raspberry Pi 4B, aarch64)

NOTE: this folder does NOT contain a compiled binary or any game data.
 1) Build:  run  build_aarch64.sh  on a 64-bit ARM Debian-type machine
            (Termux > proot-distro debian works, or a Pi on 64-bit Raspberry Pi OS).
            It produces doom64ex.aarch64 + libs.aarch64/ in this folder.
 2) Game data: put EITHER doom64.wad OR your own Doom 64 N64 ROM (.z64/.n64/.v64)
            in this folder. With a ROM, the first launch generates doom64.wad and
            doomsnd.sf2 into ./conf/doom64ex/.
 3) Copy Doom64EX.sh and the doom64ex folder to /userdata/roms/ports/ on Batocera,
    then Update Gamelists. Log is written to doom64ex/log.txt.

Controls (gptokeyb, assumes default Doom keys):
 L-stick move/strafe, R-stick turn, R2/L2 fire, A use, X run, Start menu, B enter.
If a button does nothing, rebind in Options > Controls or edit doom64ex.gptk.

If the game fails to open a GL context: the engine only does fixed-function
OpenGL 1.4. Drop a gl4es build into ./gl4es/ (libGL.so.1) and the launcher uses it.
