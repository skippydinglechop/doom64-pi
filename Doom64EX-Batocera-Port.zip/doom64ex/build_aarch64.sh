#!/bin/bash
# Build Doom64EX for aarch64 (Pi 4B). Run on ANY 64-bit ARM Debian/Ubuntu/Raspberry Pi OS box
# (e.g. Termux -> proot-distro login debian, or a Pi running 64-bit Raspberry Pi OS / Twister OS).
# Batocera itself has no compiler, so don't run this there.
set -e
cd "$(dirname "$0")"
[ "$(uname -m)" = "aarch64" ] || { echo "Needs an aarch64 machine, this is $(uname -m)"; exit 1; }

apt-get update
apt-get install -y build-essential cmake git pkg-config \
  libsdl2-dev libsdl2-net-dev libpng-dev zlib1g-dev libgl-dev libglu1-mesa-dev

cd build_src
# fluidsynth-lite (MIDI/soundfont music) - the zip's submodule folder is empty, so fetch it
if [ ! -f fluidsynth/CMakeLists.txt ]; then
  rm -rf fluidsynth
  git clone --depth 1 https://github.com/haleyjd/fluidsynth-lite.git fluidsynth
fi

rm -rf build && mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DENABLE_TESTING=OFF -DVERSION_DEV=OFF \
  -DCMAKE_C_FLAGS="-O2 -mcpu=cortex-a72" \
  -DCMAKE_CXX_FLAGS="-O2 -mcpu=cortex-a72 -std=gnu++14 -fpermissive -w -fno-strict-aliasing" \
  -DCMAKE_EXE_LINKER_FLAGS="-static-libstdc++ -static-libgcc"
make -j"$(nproc)"

cd ../..
cp build_src/build/doom64ex ./doom64ex.aarch64
strip doom64ex.aarch64
# Bundle libs Batocera is unlikely to ship (SDL2 itself comes from Batocera)
mkdir -p libs.aarch64
for l in libSDL2_net-2.0.so.0 libpng16.so.16; do
  p=$(ldconfig -p | awk -v l="$l" '$1==l{print $NF; exit}'); [ -n "$p" ] && cp -L "$p" libs.aarch64/
done
echo; echo "Done. Missing shared libs on target (if any) show with:  ldd doom64ex.aarch64"
