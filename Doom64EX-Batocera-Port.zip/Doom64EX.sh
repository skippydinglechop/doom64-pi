#!/bin/bash
# Doom64EX - PortMaster-style launcher (Batocera / Raspberry Pi 4B, aarch64)

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "/userdata/roms/ports/PortMaster/" ]; then
  controlfolder="/userdata/roms/ports/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/doom64ex"
[ -d "$GAMEDIR" ] || GAMEDIR="$(cd "$(dirname "$0")" && pwd)/doom64ex"
cd "$GAMEDIR"
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

# Config, savegames and generated files (doom64.wad, doomsnd.sf2) live in ./conf
export XDG_DATA_HOME="$GAMEDIR/conf"
mkdir -p "$XDG_DATA_HOME/doom64ex"
DATA="$XDG_DATA_HOME/doom64ex"

export LD_LIBRARY_PATH="$GAMEDIR/libs.aarch64:$LD_LIBRARY_PATH"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# Optional: if you drop a gl4es build in ./gl4es/ the game will use it
# (fallback if native desktop GL 1.4 doesn't initialise on your setup).
if [ -f "$GAMEDIR/gl4es/libGL.so.1" ]; then
  export LD_LIBRARY_PATH="$GAMEDIR/gl4es:$LD_LIBRARY_PATH"
  export LIBGL_ES=2 LIBGL_GL=21 LIBGL_FB=4
fi

BIN="$GAMEDIR/doom64ex.aarch64"
if [ ! -x "$BIN" ]; then
  echo "doom64ex.aarch64 not found - run build_aarch64.sh on an ARM64 Linux machine first (see README)."
  sleep 8; exit 1
fi

# First run: generate doom64.wad + doomsnd.sf2 from your own N64 ROM
if [ ! -f "$DATA/doom64.wad" ] && [ ! -f "$GAMEDIR/doom64.wad" ]; then
  ROM=$(ls "$GAMEDIR"/*.z64 "$GAMEDIR"/*.n64 "$GAMEDIR"/*.v64 2>/dev/null | head -n1)
  if [ -n "$ROM" ]; then
    echo "Generating doom64.wad from $ROM ..."
    "$BIN" -wadgen "$ROM"
  else
    echo "No doom64.wad and no N64 ROM found. Put doom64.wad (or a Doom 64 .z64 ROM) in $GAMEDIR"
    sleep 8; exit 1
  fi
fi

$GPTOKEYB "doom64ex.aarch64" -c "$GAMEDIR/doom64ex.gptk" &
pm_platform_helper "$BIN" >/dev/null 2>&1
"$BIN" -iwad doom64.wad "$@"

pm_finish
